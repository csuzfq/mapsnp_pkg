#' Plot genomic map for single nucleotide polymorphism.
#'
#' \tabular{ll}{
#' Package: \tab mapsnp\cr
#' Type: \tab Package\cr
#' Version: \tab 0.1\cr
#' Date: \tab 2014-03-25\cr
#' Depends: \tab R (>= 2.15.0)\cr
#' Encoding: \tab UTF-8\cr
#' License: \tab GPL (>= 3)\cr
#' LazyLoad: \tab yes\cr
#' }
#'
#' A package to plot genomic map of single nucleotide polymorphisms (SNPs), including the a chromosome ideogram, transcripts of the gene on which the SNPs map to, the genomic location of SNPs, and their ID number.
#'
#' @aliases mapsnp-package
#' @name mapsnp-package
#' @docType package
#' @title The mapsnp Package
#' @author Fuquan Zhang
#' @keywords package
NULL
