#' A function to plot genomic map of SNP using biomaRt
#' 
#' @title Plot genomic map for SNP, with all transcripts.
#' @description A function to plot genomic map of SNP using Ensembl dataset retrieved by
#'  biomaRt. The trancript track includes all the trancripts within a highlighting range.
#'  An internet connection is needed during running of the function.
#' @param axisLabPos Character vector, one in "alternating", "revAlternating", "above" or "below". 
#' The vertical positioning of the axis labels. Default to "alternating".
#' @param cex Numeric scalar. The overall font expansion factor for the axis annotation text.
#' Default to 0.6.
#' @param background.panel A character, background color of track panel. Default to "white".
#' @param background.title A character, background color of track name. Default to "grey".
#' @param end An integer scalar with the genomic end coordinates for the highlighting range.
#' @param extendL Numeric scalar, extending the plotting range to the left by times of width 
#' relative the 1/10 of length of the genetic region. Default to 1.
#' @param extendR Numeric scalar, extending the plotting range to the right by times of width 
#' relative the 1/10 of length of the genetic region. Default to 1.
#' @param geneTrName Character scalar of the transcript track name used in the title panel 
#' when plotting. Default to "Transcripts".
#' @param genome The genome on which the track ranges are defined. Usually this is a valid UCSC 
#' genome identifier. Default to "hg19".
#' @param littleTicks littleTicks=FALSE: Logical scalar. Add more fine-grained tick marks. 
#' Default to FALSE.
#' @param M A three-column matrix or data.fram. The first column is Chromosome, e.g. 1, 2, 3, ..., 
#' X, Y, the second column is SNP ID, and the third column is SNP genomic location.  
#' @param reverseStrand By default all tracks will be plotted in a 5' -> 3' direction. It sometimes 
#' can be useful to actually show the data relative to the opposite strand. To this end one can use 
#' the reverseStrand display parameter, which does just what its name suggests. Default to FALSE.
#' @param showLab.chr Logical scalar. Control whether to plot the chromosome ideogram track item 
#' identifiers. Default to TRUE.
#' @param showLab.geneTr Logical scalar. Control whether to plot the transcripts track item 
#' identifiers. Default to TRUE.
#' @param showLab.SNPbp Logical scalar. Control whether to plot the SNP location track item 
#' identifiers. Default to FALSE.
#' @param showLab.SNPid Logical scalar. Control whether to plot the SNP ID track item identifiers. 
#' Default to TRUE.
#' @param SNPbpFill Character or integer scalar. The fill color for SNP location items. 
#'  Default to "black".
#' @param SNPbpLab item labels for SNP location. Default to series from 1 to number of rows.
#' @param SNPbpTrName Character scalar of the SNP location track name used in the title panel 
#' when plotting. Default to "SNP".
#' @param SNPbpWd Integer vectors, times of width relative the 1/140 of length of the genetic region 
#' for the SNP location track items. Default to 1.
#' @param SNPidPos Character vector, one in "alternating", "above" or "below". 
#' The vertical positioning of the SNP ID labels. Default to "alternating".
#' @param SNPidTrName Character scalar of the SNP ID track name used in the title panel when plotting.
#' Default to "ID".
#' @param SNPidWd Integer vectors, times of width relative the 1/20 of length of the genetic region 
#' for the SNP ID track items. Default to 1.
#' @param stackHt.geneTr Numeric between 0 and 1. Controls the vertical size and spacing between 
#' stacked elements. The number defines the proportion of the total available space for the stack 
#' that is used to draw the transcripts items. Default to 0.5.
#' @param stackHt.SNPbpTr Numeric between 0 and 1. Controls the vertical size and spacing between 
#' stacked elements. The number defines the proportion of the total available space for the stack 
#' that is used to draw the SNP location items. Default to 0.5.
#' @param stackHt.SNPidTr Numeric between 0 and 1. Controls the vertical size and spacing between 
#' stacked elements. The number defines the proportion of the total available space for the stack 
#' that is used to draw the SNP ID items. Default to 0.2.
#' @param stacking Object of class "character", the stacking type of overlapping items on the 
#' final plot. One in c(hide, dense, squish, pack,full). Currently, only hide (do not show the track 
#' items at all), squish (make best use of the available space) and dense (no stacking at all) are 
#' implemented. Default to "squish".
#' @param start An integer scalar with the genomic start coordinates for the highlighting range. 
#' @param ... Additional items which will all be interpreted as further display parameters. See 
#' settings and the "Display Parameters" section below for details. 
#' @import Gviz
#' 
#' @examples
#' 
#' \dontrun{
#' data(snp)
#' msa(M=snp,start=111950277,end=112036294)
#' }
#' 
#' @export 
#'     


msa <- function (M, start=start, end=end, extendL=1, extendR=1, cex=0.6,
                 showLab.chr=TRUE, axisLabPos="alternating", littleTicks=FALSE,
                 geneTrName="Transcripts", showLab.geneTr=TRUE, stackHt.geneTr=0.5,
                 SNPbpTrName='SNP', SNPbpLab=1:nr, showLab.SNPbp=FALSE, SNPbpWd=1, 
                 SNPbpFill="black", stackHt.SNPbpTr=0.5,
                 SNPidTrName="ID", showLab.SNPid=TRUE, SNPidWd=1,
                 SNPidPos="below", stackHt.SNPidTr=0.2,
                 stacking="squish",  genome="hg19", reverseStrand=FALSE, 
                 background.panel="white", background.title = "grey", ...) {
  
  names(M) <- c('Chr', 'id', 'bp')
  M=M[order(M$bp),]
  start <- range(M$bp)[1]
  end <- range(M$bp)[2]
  nr <- dim(M)[1]
  wd <- round((end-start)/20)
  chr <- paste('chr', M[1,1], sep='')
  
  
  chrTr <- IdeogramTrack(genome = genome, chromosome=chr, showFeatureId="showLab.chr", cex=cex+0.1)
  
  axisTr <- GenomeAxisTrack(cex=cex+0.1)
  
  geneTr <- BiomartGeneRegionTrack(chromosome=chr, start=start, end=end, showId=TRUE, genome=genome,
                                   name=geneTrName, showFeatureId=TRUE, stackHeight=stackHt.geneTr)
  
  SNPbpTr <- AnnotationTrack(start=M$bp, width=round(wd/7)*SNPbpWd, chromosome=chr, id=SNPbpLab, 
                             genome=genome, name=SNPbpTrName, showFeatureId=showLab.SNPbp,
                             fill=SNPbpFill, stackHeight=stackHt.SNPbpTr, cex=cex)  
  
  SNPidTr <- AnnotationTrack(start=M$bp-wd*SNPidWd, width=wd*SNPidWd*2, chromosome=chr, id=M$id,
                             genome=genome, name=SNPidTrName, showFeatureId=showLab.SNPid,
                             fill="white", fontcolor="black", stackHeight=stackHt.SNPidTr, cex=cex)
  if (SNPidPos=="below"){
    plotTracks(list(chrTr, axisTr, geneTr, SNPbpTr, SNPidTr),
               extend.left=wd*extendL, extend.right=wd*extendR, labelPos=axisLabPos,
               littleTicks=littleTicks, reverseStrand=reverseStrand,
               background.panel=background.panel, background.title =background.title, ...)
  }
  else if (SNPidPos=="above"){
    plotTracks(list(chrTr, axisTr, geneTr, SNPidTr, SNPbpTr),
               extend.left=wd*extendL, extend.right=wd*extendR, labelPos=axisLabPos,
               littleTicks=littleTicks, reverseStrand=reverseStrand,
               background.panel=background.panel, background.title =background.title, ...)
  }
  else if (SNPidPos=="alternating"){
    M1 <- M[1:nr%%2==0, ]
    M2 <- M[1:nr%%2==1, ]
    
    SNPidTr1 <- AnnotationTrack(start=M1$bp-wd*SNPidWd, width=wd*SNPidWd*2, chromosome=chr, 
                                id=M1$id, cex=cex,
                                genome=genome, name=SNPidTrName, showFeatureId=showLab.SNPid,
                                fill="white", fontcolor="black", stackHeight=stackHt.SNPidTr)
    
    SNPidTr2 <- AnnotationTrack(start=M2$bp-wd*SNPidWd, width=wd*SNPidWd*2, chromosome=chr, 
                                id=M2$id, cex=cex,
                                genome=genome, name=SNPidTrName, showFeatureId=showLab.SNPid,
                                fill="white", fontcolor="black", stackHeight=stackHt.SNPidTr)
    
    plotTracks(list(chrTr, axisTr, geneTr, SNPidTr1, SNPbpTr, SNPidTr2), 
               extend.left=wd*extendL, extend.right=wd*extendR, labelPos=axisLabPos,
               littleTicks=littleTicks, reverseStrand=reverseStrand,
               background.panel=background.panel, background.title =background.title, ...)
  }
}
